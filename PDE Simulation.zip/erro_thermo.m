global erro;
global dx_A
global dy_A
global x_1_1
global y_1_1
global T_L
global T_H

%initial value setting
dx = 0.25*dx_A;
dy = 0.25*dy_A;     
cmpr = 1;
re = 0;a = 1;
temp_max=100;
temp_min=0;
lengthx = 0.4;
lengthy = 0.8;

%relaxation factor
omega = 1.995;
delta = 1-omega;


%constant of equation
c_1 = dx^2;
c_2 = dy^2;
c1 = 1/(2*c_1+2*c_2);
c11 = c1*c_1;c12 = c1*c_2;

%grid setting
m_nx = 0:dx:lengthx+dx;
m_ny = 0:dy:lengthy+dy;
nx = length(m_nx);
ny = length(m_ny);

%initial grid value guess
tempnew=zeros(ny,nx);
tempold = tempnew;
 
%extrat the oders of points on the circle
x_circle = 1:nx;
y_circle = 1:ny;
[cx,cy]=meshgrid(x_circle,y_circle);
cor = find((((cx)*dx-x_1_1).^2+((cy)*dy-y_1_1).^2) <= 0.05*0.05);

%define area of heat & cool area(hc)
m_hc_y = 0:dy:lengthy/4;
m_hc_x = 0:dy:lengthx/4;
hc_vertical = length(m_hc_y);
hc_horizontal = length(m_hc_x);

sidepoint1 = find((cy<=ny-1)&(cy>=ny-hc_horizontal)&(cx>=nx-2)&(cx<=nx-1));
sidepoint2 = find((cy>=ny-2)&(cx<=nx-1)&(cx>=nx-hc_vertical)&(cy<=ny-1));
sidepoint3 = find((cy<=hc_horizontal)&(cy>=1)&(cx<=2)&(cx>=1));
sidepoint4 = find((cy<=2)&(cx>=1)&(cx<=hc_vertical)&(cy>=1));

sidepoint_max = union(sidepoint1,sidepoint2);
sidepoint_min = union(sidepoint3,sidepoint4);

denominator = nx*ny;

j= 2:1:(ny-2);
i= 2:1:(nx-2);
while re < 2
    %successive overrelaxation
    tempnew(j,i)=delta*tempold(j,i)+omega*(c11*(tempold(j,i+1)+tempold(j,i-1))+c12*(tempold(j+1,i)+tempold(j-1,i)));
    tempnew(j+1,i+1)=delta*tempold(j+1,i+1)+omega*(c11*(tempold(j+1,i+2)+tempold(j+1,i))+c12*(tempold(j+2,i+1)+tempold(j,i+1)));
    tempnew(j+1,i)=delta*tempold(j+1,i)+omega*(c11*(tempnew(j+1,i+1)+tempnew(j+1,i-1))+c12*(tempnew(j+2,i)+tempnew(j,i)));
    tempnew(j,i+1)=delta*tempold(j,i+1)+omega*(c11*(tempnew(j,i+2)+tempnew(j,i))+c12*(tempnew(j+1,i+1)+tempnew(j-1,i+1)));

    %assign value for heat-cool area
    tempnew(sidepoint_max) = T_H;
    tempnew(sidepoint_min) = T_L;

    %copy next-inner-most value to boundary
    tempnew([1 ny],1:nx)=tempnew([2 ny-1],1:nx);
    tempnew(1:ny,[1 nx])=tempnew(1:ny,[2 nx-1]);

    %assign value for circle
    tempnew(cor) = mean(tempnew(cor));
    erro = sum(sum(abs(tempnew-tempold)))/denominator;

    tempold = tempnew;
    re=re+1;
end