%Extracting erro
function erro_fluid
global erro
global upspeed
global dx_B
global dy_B

%setting the center of circle
% circle 1
    global x_2_1
    global y_2_1
% circle 2
    global x_2_2
    global y_2_2
% circle 3
    global x_2_3
    global y_2_3
% circle 4
    global x_2_4
    global y_2_4
% circle 5
    global x_2_5
    global y_2_5
% circle 6
    global x_2_6
    global y_2_6
    
%initail value setting
dx=0.25*dx_B;
dy=0.25*dy_B;
lengthx = 4;
lengthy = 2;
re = 0;

%first grid setting
m_nx = 0:dx:lengthx;
m_ny = 0:dy:lengthy;
nx = length(m_nx);
ny = length(m_ny);

flowold = zeros(ny,nx);
flownew = flowold;

%inflow stream function value
flownew(1:2,1:nx) = 0;
flownew(ny-1:ny,1:nx) = lengthy*upspeed;
for n = 3:ny-2
    flownew(n,[1:2,nx-1:nx]) = flownew(n-1,[1:2,nx-1:nx])+upspeed*dy;
end

%cylinder defination & extract points of cylinder
c_1 = dx^2;
c_2 = dy^2;
c_3 = 1/(2*c_2+2*c_1);
a = 1:nx;b = 1:ny;
[x,y] = meshgrid(a,b);
c1 = (x*dx-x_2_1).^2+(y*dy-y_2_1).^2;
c2 = (x*dx-x_2_2).^2+(y*dy-y_2_2).^2;
c3 = (x*dx-x_2_3).^2+(y*dy-y_2_3).^2;
c4 = (x*dx-x_2_4).^2+(y*dy-y_2_4).^2;
c5 = (x*dx-x_2_5).^2+(y*dy-y_2_5).^2;
c6 = (x*dx-x_2_6).^2+(y*dy-y_2_6).^2;

c1 = c1<=0.2*0.2;
c2 = c2<=0.2*0.2;
c3 = c3<=0.3*0.3;
c4 = c4<=0.3*0.3;
c5 = c5<=0.2*0.2;
c6 = c6<=0.2*0.2;

j= 3:ny-2;
i= 3:nx-2;
while re <2
    %Jacobi method
    flownew(j,i) = c_3*(c_2*(flowold(j,i+1)+flowold(j,i-1))+c_1*(flowold(j+1,i)+flowold(j-1,i)));
    %assign values for cylinders
    flownew(c1)=y_2_1*upspeed;
    flownew(c2)=y_2_2*upspeed;
    flownew(c5)=y_2_5*upspeed;
    flownew(c6)=y_2_6*upspeed;
    flownew(c3)=y_2_3*upspeed;
    flownew(c4)=y_2_4*upspeed;

    %average error
    erro = mean2(abs(flownew-flowold));        
    flowold = flownew;
    re = re+1;
end