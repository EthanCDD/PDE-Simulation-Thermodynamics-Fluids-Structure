function Fluid_dynamics
%problem 2
tic
global dx_B
global dy_B
global upspeed
global iterationB
global tol_B
global erro

% circle 1
    global x_2_1
    global y_2_1
% circle 2
    global x_2_2
    global y_2_2
% circle 3
    global x_2_3
    global y_2_3
% circle 4
    global x_2_4
    global y_2_4
% circle 5
    global x_2_5
    global y_2_5
% circle 6
    global x_2_6
    global y_2_6

dx_B1=dx_B;
dy_B1=dy_B;
erro_fluid;

%initial value setting
a = 1;
re = 0;
cmpr = 1;
iterationB=[];
lengthx = 4;lengthy = 2;

%coarsest grid length setting
m_nx = 0:dx_B:lengthx;
m_ny = 0:dy_B:lengthy;
nx = length(m_nx);
ny = length(m_ny);

%initial grid value guess
flownew=2*rand(ny,nx);

%Three times enlargements
while re <3
    %From coarse grid to fine grid
    while re == cmpr
        dx_B = dx_B/2;
        dy_B = dy_B/2;
        m_nx_r = 0:dx_B:lengthx;
        m_ny_r = 0:dy_B:lengthy;
        [xr,yr] = meshgrid(m_nx_r,m_ny_r);
        [x,y] = meshgrid(m_nx,m_ny);
        flownew = interp2(x,y,flownew,xr,yr);
        m_nx=m_nx_r;
        m_ny=m_ny_r;
        nx = length(m_nx);
        ny = length(m_ny);
        cmpr = cmpr+1;
    end
    
    %inflow stream function value
    flowold = flownew;
    flownew(1:2,1:nx) = 0;
    flownew(ny-1:ny,1:nx) = lengthy*upspeed;
    for n = 3:ny-2
        flownew(n,[1:2,nx-1:nx]) = flownew(n-1,[1:2,nx-1:nx])+upspeed*dy_B;
    end
    
    %cylinder defination & extract points of cylinder
    c_1 = dx_B^2;
    c_2 = dy_B^2;
    c_3 = 1/(2*c_2+2*c_1);
    a = 1:nx;b = 1:ny;
    [x,y] = meshgrid(a,b);
    c1 = (x*dx_B-x_2_1).^2+(y*dy_B-y_2_1).^2;
    c2 = (x*dx_B-x_2_2).^2+(y*dy_B-y_2_2).^2;
    c3 = (x*dx_B-x_2_3).^2+(y*dy_B-y_2_3).^2;
    c4 = (x*dx_B-x_2_4).^2+(y*dy_B-y_2_4).^2;
    c5 = (x*dx_B-x_2_5).^2+(y*dy_B-y_2_5).^2;
    c6 = (x*dx_B-x_2_6).^2+(y*dy_B-y_2_6).^2;

    c1 = find(c1<=0.2^2);
    c2 = find(c2<=0.2^2);
    c3 = find(c3<=0.3^2);
    c4 = find(c4<=0.3^2);
    c5 = find(c5<=0.2^2);
    c6 = find(c6<=0.2^2);
    
    err = 1;
    j= 3:ny-2;
    i= 3:nx-2;
    while err/erro>tol_B
       %Jacobi method
       flownew(j,i) = c_3*(c_2*(flowold(j,i+1)+flowold(j,i-1))+c_1*(flowold(j+1,i)+flowold(j-1,i)));
       %assign value for cylinders
       flownew(c1)=y_2_1*upspeed;
       flownew(c2)=y_2_2*upspeed;
       flownew(c3)=y_2_3*upspeed;
       flownew(c4)=y_2_4*upspeed;
       flownew(c5)=y_2_5*upspeed;
       flownew(c6)=y_2_6*upspeed;
       %average error
       err = mean2(abs(flownew-flowold));        
       flowold = flownew;
       iterationB(a) = err;
       a = a+1;
    end
    re = re+1;
end
x = 0:dx_B:lengthx;
y = 0:dy_B:lengthy;
z = flownew;
contour(x,y,z,60);
colorbar;
xlabel('Length of x dimention, m');
ylabel('Length of y dimention, m');
dx_B=dx_B1;
dy_B=dy_B1;
viscircles([x_2_1 y_2_1],0.2,'linewidth',3)
viscircles([x_2_2 y_2_2],0.2,'linewidth',3)
viscircles([x_2_3 y_2_3],0.3,'linewidth',3)
viscircles([x_2_4 y_2_4],0.3,'linewidth',3)
viscircles([x_2_5 y_2_5],0.2,'linewidth',3)
viscircles([x_2_6 y_2_6],0.2,'linewidth',3)
toc
