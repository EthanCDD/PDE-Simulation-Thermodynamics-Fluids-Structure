function Thermo_dynamics
tic
global dx_A
global dy_A
global x_1_1
global y_1_1
global erro
global T_L
global T_H
global timeA
global iterationA
global tol_A

dx_A1=dx_A;
dy_A1=dy_A;

%gauss-sedail
erro_thermo

%initial value setting
cmpr = 1;
re = 0;
a = 1;
iterationA=[];
lengthx = 0.4;
lengthy = 0.8;

%relaxation factor
omega = 1.995;
delta = 1-omega;

%constant of equation
c_1 = dx_A^2;
c_2 = dy_A^2;
c1 = 1/(2*c_1+2*c_2);
c11 = c1*c_1;c12 = c1*c_2;

%first grid setting
m_nx = 0:dx_A:lengthx+dx_A;
m_ny = 0:dy_A:lengthy+dy_A;
nx = length(m_nx);
ny = length(m_ny);

% initial grid setting
tempnew = zeros(ny,nx);
tempold = tempnew;

%three times enlargements
while re < 3  
    %coarse grid to fine grid
    while re == cmpr  
        dx_A = dx_A/2;
        dy_A = dy_A/2;
        m_nx_r = 0:dx_A:lengthx+dx_A;
        m_ny_r = 0:dy_A:lengthy+dy_A;
        [xr,yr] = meshgrid(m_nx_r,m_ny_r);
        [x,y] = meshgrid(m_nx,m_ny);
        tempold = interp2(x,y,tempnew,xr,yr);
        m_nx=m_nx_r;
        m_ny=m_ny_r;
        nx = length(m_nx);
        ny = length(m_ny);
        cmpr = cmpr+1;
        c_1 = dx_A^2;
        c_2 = dy_A^2;
        c1 = 1/(2*c_1+2*c_2);
        c11 = c1*c_1;c12 = c1*c_2;   
        tempnew=tempold;
    end
    
    %extrat the points of the conducting liquid(circle)
    x_circle = 1:nx;
    y_circle = 1:ny;
    [cx,cy]=meshgrid(x_circle,y_circle);
    cor = find(((cx*dx_A-x_1_1).^2+(cy*dy_A-y_1_1).^2) <= 0.05^2);
    
    %define area of heat & cool area(hc)
    m_hc_y = 0:dy_A:lengthy/4;
    m_hc_x = 0:dx_A:lengthx/4;
    hc_vertical = length(m_hc_y);
    hc_horizontal = length(m_hc_x);

    sidepoint1 = find((cy<=ny-1)&(cy>=ny-hc_horizontal)&(cx>=nx-2)&(cx<=nx-1));
    sidepoint2 = find((cy>=ny-2)&(cx<=nx-1)&(cx>=nx-hc_vertical)&(cy<=ny-1));
    sidepoint3 = find((cy<=hc_horizontal)&(cy>=1)&(cx<=2)&(cx>=1));
    sidepoint4 = find((cy<=2)&(cx>=1)&(cx<=hc_vertical)&(cy>=1));
    
    sidepoint_max = union(sidepoint1,sidepoint2);
    sidepoint_min = union(sidepoint3,sidepoint4);
    
    denominator = nx*ny;
    
    errc = 1;
    j= 2:2:(ny-2);
    i= 2:2:(nx-2);
    while errc/erro > tol_A
        %successive overrelaxation
        tempnew(j,i)=delta*tempold(j,i)+omega*(c11*(tempold(j,i+1)+tempold(j,i-1))+c12*(tempold(j+1,i)+tempold(j-1,i)));
        tempnew(j+1,i+1)=delta*tempold(j+1,i+1)+omega*(c11*(tempold(j+1,i+2)+tempold(j+1,i))+c12*(tempold(j+2,i+1)+tempold(j,i+1)));
        tempnew(j+1,i)=delta*tempold(j+1,i)+omega*(c11*(tempnew(j+1,i+1)+tempnew(j+1,i-1))+c12*(tempnew(j+2,i)+tempnew(j,i)));
        tempnew(j,i+1)=delta*tempold(j,i+1)+omega*(c11*(tempnew(j,i+2)+tempnew(j,i))+c12*(tempnew(j+1,i+1)+tempnew(j-1,i+1)));
       
        %assign value for heat-cool area
        tempnew(sidepoint_max) = T_H;%temp_max;
        tempnew(sidepoint_min) = T_L;%temp_min;
        
        %copy next-inner-most value to boundary
        tempnew([1 ny],1:nx)=tempnew([2 ny-1],1:nx);
        tempnew(1:ny,[1 nx])=tempnew(1:ny,[2 nx-1]);
        
        %assign value for circle
        tempnew(cor) = mean(tempnew(cor));
        errc = sum(sum(abs(tempnew-tempold)))/denominator;

        tempold = tempnew;
        iterationA(a) = errc;
        a = a+1;
    end
    re=re+1;
end
%Get rid of the boundary side and assign new boundary with next-inner-most value. In order to reach the requirement, the tolerance is lowered
tempnew(:,nx)=[];
tempnew(ny,:)=[];
tempnew(1:ny-1,nx-1)=tempnew(1:ny-1,nx-2);
tempnew(ny-1,1:nx-1)=tempnew(ny-2,1:nx-1);
cla
mesh(tempnew);
toc
timeA=toc;
x1 = xlabel('length of x dimention/dx');
x2 = ylabel('length of y dimention/dy');
zlabel('Temperature, Celsius degree');
set(x1, 'Rotation',15);
set(x2, 'Rotation',-25);
dx_A=dx_A1;
dy_A=dy_A1;
end



