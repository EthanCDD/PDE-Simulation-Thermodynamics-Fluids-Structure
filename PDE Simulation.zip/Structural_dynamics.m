%Jacobi method
function Structural_dynamics
tic
global erro
global iterationC
global dx_C
global dy_C
global x_3_g
global y_3_g
global x_3_r
global y_3_r
global tol_C
dx_C1=dx_C;
dy_C1=dy_C;

%For extracting erro
erro_structure

%initial value setting
r = 0.1;
re = 0;
cpr = 1;
m = 56;
k = 60000;
g = 9.81;
a = 2*pi*r^2;
lengthx = 4;
lengthy = 2;
con = m*g/(a*k);

%first grid setting
m_nx = 0:dx_C:lengthx;
m_ny = 0:dy_C:lengthy;
nx = length(m_nx);
ny = length(m_ny);

%initial grid value guess
stressold = zeros(ny,nx);
iterationC=[];
a = 1;

while re<4
    %From coarse grid to fine grid
    while cpr == re
        dx_C = dx_C/2;
        dy_C = dy_C/2;
        m_nx_r = 0:dx_C:lengthx;
        m_ny_r = 0:dy_C:lengthy;
        [xr,yr] = meshgrid(m_nx_r,m_ny_r);
        [x,y] = meshgrid(m_nx,m_ny);
        stressold = interp2(x,y,stressnew,xr,yr);
        m_nx=m_nx_r;
        m_ny=m_ny_r;
        nx = length(m_nx);
        ny = length(m_ny);
        cpr = cpr+1;
    end

    %rip definition
    rip_d = fix(y_3_r/dy_C);
    rip_u = fix((y_3_r+0.3)/dy_C);
    rip_p = fix(x_3_r/dx_C);
    %constant of Jacobi equation
    c_1 = dx_C^2;
    c_2 = dy_C^2;
    c3 = 1/(2*c_2+2*c_1);
    c11 = c3*c_1;c12 = c3*c_2;
    %feet area
    x_circle = 1:nx;
    y_circle = 1:ny;
    [cir_x,cir_y]=meshgrid(x_circle,y_circle);
    cor1 = find((cir_x*dx_C-x_3_g).^2+(cir_y*dy_C-y_3_g).^2 <= 0.1^2);
    cor2 = find((cir_x*dx_C-x_3_g).^2+(cir_y*dy_C-(y_3_g+0.2)).^2 <= 0.1^2);
    cor = union(cor1,cor2);
    
    stressnew = stressold;
    errc = 1;
    while errc>tol_C*erro
        j= 3:ny-2;
        i= 3:nx-2;
        stressnew(j,i) = c12*(stressold(j,i+1)+stressold(j,i-1))+c11*(stressold(j+1,i)+stressold(j-1,i));  
        %feet depth
        stressnew(cor) = -con;
        %rip length
        stressnew(rip_d:rip_u,rip_p)=stressnew(rip_d:rip_u,rip_p-1);
        stressnew(rip_d:rip_u,rip_p+1)=stressnew(rip_d:rip_u,rip_p+2);
        stressnew(rip_d-1, rip_p)=stressnew(rip_d-1,rip_p+1);
        stressnew(rip_u+1, rip_p)=stressnew(rip_u+1,rip_p+1);
        %average error
        errc = mean2(abs(stressnew-stressold)); 
        stressold = stressnew;
        iterationC(a) = errc;
        a = a+1;
    end
    re = re+1;
end

mesh(stressnew);
x1 = xlabel('Length of x dimension/dx');
x2 = ylabel('Length of y dimension/dy');
zlabel('Displacement, m');
set(x1, 'Rotation',15);
set(x2, 'Rotation',-25);
dx_C=dx_C1;
dy_C=dy_C1;
toc
end

