% All programs for three tasks can be controlled by Gui
Gui